const { uniV3Export } = require("../helper/uniswapV3");

module.exports = uniV3Export({
  arbitrum: {
    factory: "0x855f2c70cf5cb1d56c15ed309a4dfefb88ed909e",
    fromBlock: 86863305,
  },
});