module.exports = {
  methodology: 'Project is abandoned',
  bsc: {
    tvl: () => 0
  },
}
