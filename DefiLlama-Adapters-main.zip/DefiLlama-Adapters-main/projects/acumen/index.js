module.exports = {
  timetravel: false,
  solana: { tvl: () => ({}) },
  hallmarks: [
    [Math.floor(new Date('2022-12-12')/1e3), 'Product is deprecated'],
  ],
  methodology: `Product is deprecated. More information: https://acumenofficial.medium.com/acumen-stable-dapp-update-7e96333e9318`,
}