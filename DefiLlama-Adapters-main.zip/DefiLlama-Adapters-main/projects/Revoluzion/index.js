module.exports = {
  bsc: {
    tvl: () => 0,
  }
}
