const { dexExport } = require('../helper/chain/aptos')

module.exports = dexExport({
  account: '0x6b1a0749af672861c5dfd301dcd7cf85973c970d6088bae4f4a34e2effcb9e5e',
  poolStr: 'AtodexSwapPoolV1::LiquidityPool',
})
