const { uniV3Export } = require('../helper/uniswapV3')

module.exports = uniV3Export({
  astar: { factory: '0x0bA242809B5b8AC2C362372807bc616fc620DB97', fromBlock: 3333333, },
})
