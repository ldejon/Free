

module.exports = {
  timetravel: false, 
  solana: {
    tvl: () => 0,
  },
  methodology: 'website unreachable, twitter deleted',
}
