const { uniV3Export } = require('../helper/uniswapV3')

module.exports = uniV3Export({
  moonbeam: { factory: '0xd118fa707147c54387b738f54838ea5dd4196e71', fromBlock: 3579833 },
})
