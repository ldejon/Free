
 module.exports = {
   fantom: {
    tvl: () => 0,
   } 
 };