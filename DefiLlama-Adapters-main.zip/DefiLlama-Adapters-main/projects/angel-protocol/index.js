module.exports = {
  timetravel: false,
  methodology: 'TVL takes total apANC in the contract and returns AnchorUST value',
  terra: {
    tvl: () => ({}),
  },
   hallmarks:[
    [1651881600, "UST depeg"],
  ]
}
