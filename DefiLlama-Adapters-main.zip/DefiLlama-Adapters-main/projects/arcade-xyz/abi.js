const VAULT_FACTORY_ABI = 'event VaultCreated(address vault,address to)'

module.exports = {
  VAULT_FACTORY_ABI,
};
