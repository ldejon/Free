const { uniTvlExport } = require('../helper/unknownTokens')

module.exports = uniTvlExport('xdai', '0x45DE240fbE2077dd3e711299538A09854FAE9c9b')